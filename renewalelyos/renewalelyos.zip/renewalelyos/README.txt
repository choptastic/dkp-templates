Copyright 2007 Brandon Rinker. Being released under the Creative Commons Attribution-Noncommercial-Share Alike 3.0 license: http://creativecommons.org/licenses/by-nc-sa/3.0/us/
