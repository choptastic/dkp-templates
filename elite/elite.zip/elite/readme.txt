Originally designed by Nicolas Condaras for the guild "Reckoning" on server "Garithos".  WoW graphics are copyright Blizzard Entertainment.

Released under Creative Commons Attribution-Noncommercial-Share Alike 3.0 license: http://creativecommons.org/licenses/by-nc-sa/3.0/us/
