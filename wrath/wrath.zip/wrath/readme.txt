Copyright 2008 Sigma Star Systems (DKPSystem.com)
Some of the graphics are Copyright Blizzard Entertainment.
The code is offered under Creative Commons Attribution-Noncommercial-Share Alike 3.0 United States License
http://creativecommons.org/licenses/by-nc-sa/3.0/us/

Special Thanks to Jan Bosman for the vast majority of the development. www.jbosman.net
