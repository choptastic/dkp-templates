The WorldofWarcraft.com Site Template for DKPSystem.com
The Layout.html and menupage.html files Copyright (c) 2007 Sigma Star Systems
The Images Copyright (c) By Blizzard Entertainment
Distributed by DKPSystem.com