Copyright 2012 DKPSystem.com. Being released under the Creative Commons Attribution-Noncommercial-Share Alike 3.0 license: http://creativecommons.org/licenses/by-nc-sa/3.0/us/
