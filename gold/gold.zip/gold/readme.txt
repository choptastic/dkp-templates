The Gilded Site Template
Copyright (c) 2007 Sigma Star Systems
Distributed by DKPSystem.com

The licence of use for this layout and images 
is exclusively for a DKPsystem.com site, and 
is not authorized for any other use or hosting.