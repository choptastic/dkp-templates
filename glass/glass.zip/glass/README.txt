The HTML and CSS code and layout images on this site are Copyright 2007 David Wilson, except as noted.
The Background image (which looks like Broken Glass") is Copyright by Derek Williamson, Powerhouse Museum, Sydney Australia http://www.powerhousemuseum.com)
This is being distributed as a license for free use with DKPSystem.com sites.