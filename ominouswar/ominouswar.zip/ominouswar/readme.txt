Ominous Age of Conan Template by DKPSystem.com.  Special Thanks to Justin Milani from "The Ominous" guild (www.theominous.net).

Age of Conan Images are copyright Funcom.
